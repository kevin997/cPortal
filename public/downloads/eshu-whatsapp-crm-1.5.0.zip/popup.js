/**
 * popup.js — small status popup shown from the toolbar icon.
 */

import { parseEmailCandidates } from "./lib/email-extract.js";

const SESSION_COUNTER_KEY = "leadsSavedThisSession";

// Mirrors the server-side cap on WebLeadBulkRequest.items (src/schemas.py).
const MAX_ITEMS_PER_REQUEST = 200;

document.addEventListener("DOMContentLoaded", init);
document.getElementById("optionsLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

async function init() {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  const configured = Boolean(apiUrl && token);

  const dot = document.getElementById("statusDot");
  const text = document.getElementById("statusText");

  if (configured) {
    dot.className = "dot dot-ok";
    text.textContent = "Configuré";
  } else {
    dot.className = "dot dot-off";
    text.textContent = "Non configuré";
  }

  const { [SESSION_COUNTER_KEY]: count } = await chrome.storage.local.get(SESSION_COUNTER_KEY);
  document.getElementById("countText").textContent = `${count || 0} lead(s) enregistré(s) cette session`;
}

/**
 * Runs in the PAGE context (injected via executeScript), so it may not
 * reference anything from the popup scope and must return structured-cloneable
 * plain data. Collects strings only; all parsing happens in the popup.
 */
function collectPageStrings() {
  // Only visible text counts: an address inside inline JSON-LD or a JS config
  // object is not publicly displayed, so it must not be captured.
  const SKIP_TAGS = new Set(["SCRIPT", "STYLE", "NOSCRIPT", "TEMPLATE"]);

  const mailtoHrefs = [...document.querySelectorAll('a[href^="mailto:"]')].map((a) => a.getAttribute("href"));

  const texts = [];
  for (const el of document.querySelectorAll("body *")) {
    if (SKIP_TAGS.has(el.tagName)) continue;

    // The element's own direct text nodes, not textContent: a leaf-only
    // filter drops "…<strong>Jean</strong> : jean@acme.test", while
    // textContent would repeat every descendant on each ancestor.
    let own = "";
    for (const node of el.childNodes) {
      if (node.nodeType === Node.TEXT_NODE) own += node.nodeValue;
    }
    own = own.trim();
    if (!own) continue;

    const context =
      el.closest("section, article, footer, header, div")?.querySelector("h1, h2, h3, label")?.textContent?.trim() || null;
    texts.push({ text: own, context });
  }

  return { mailtoHrefs, texts, pageUrl: location.href, pageTitle: document.title };
}

let candidates = [];

document.getElementById("extractBtn").addEventListener("click", async () => {
  const msg = document.getElementById("extractMsg");
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  // Parsed only to reject non-https / unparseable pages: clicking the toolbar
  // action already grants `activeTab` access to this tab, which is all
  // executeScript needs. Requesting the origin as a permanent host permission
  // would leave standing access to every site ever scraped.
  const parsedUrl = (() => { try { return new URL(tab.url); } catch { return null; } })();
  if (!parsedUrl || !tab.url.startsWith("https://")) {
    msg.textContent = "Extraction impossible sur cette page.";
    return;
  }

  let injected;
  try {
    [injected] = await chrome.scripting.executeScript({ target: { tabId: tab.id }, func: collectPageStrings });
  } catch {
    msg.textContent = "Extraction impossible sur cette page.";
    return;
  }

  // executeScript can resolve to an empty array, or to a frame result with no
  // `result` (frame gone mid-call); an unguarded destructure would throw
  // outside the try above and leave the button looking dead.
  if (!injected?.result) {
    msg.textContent = "Extraction impossible sur cette page.";
    return;
  }

  candidates = parseEmailCandidates(injected.result);
  if (candidates.length === 0) {
    msg.textContent = "Aucun email trouvé sur cette page.";
    document.getElementById("results").hidden = true;
    return;
  }

  msg.textContent = `${candidates.length} email(s) trouvé(s).`;
  const list = document.getElementById("resultList");
  list.innerHTML = "";
  candidates.forEach((candidate, index) => {
    const li = document.createElement("li");
    const label = document.createElement("label");
    const box = document.createElement("input");
    box.type = "checkbox";
    box.dataset.index = String(index);
    box.checked = !candidate.suspected_noise;
    label.append(box, document.createTextNode(` ${candidate.email}`));
    if (candidate.context) {
      const small = document.createElement("small");
      small.textContent = ` — ${candidate.context}`;
      label.append(small);
    }
    li.append(label);
    list.append(li);
  });
  document.getElementById("results").hidden = false;
});

document.getElementById("saveBtn").addEventListener("click", async () => {
  const msg = document.getElementById("extractMsg");
  const chosen = [...document.querySelectorAll("#resultList input:checked")]
    .map((box) => candidates[Number(box.dataset.index)])
    .map(({ email, source_url, page_title, context }) => ({ email, source_url, page_title, context }));

  if (chosen.length === 0) {
    msg.textContent = "Sélectionnez au moins un email.";
    return;
  }

  // The API rejects a batch over MAX_ITEMS outright (422), which no retry can
  // fix — so send the first slice and say so instead of failing forever.
  const sent = chosen.slice(0, MAX_ITEMS_PER_REQUEST);
  const truncated = chosen.length > sent.length;

  const result = await chrome.runtime.sendMessage({ type: "postWebLeads", items: sent });

  if (result?.error === "not_configured") {
    msg.textContent = "Extension non configurée.";
    return;
  }
  if (result?.error) {
    // Leave the selection on screen so a retry does not lose the ticking.
    msg.textContent = "Échec de l'enregistrement. Réessayez.";
    return;
  }
  msg.textContent = truncated
    ? `${result.created} enregistré(s), ${result.skipped} déjà connu(s). ${sent.length} email(s) envoyé(s) sur ${chosen.length} sélectionné(s) : maximum ${MAX_ITEMS_PER_REQUEST} par envoi.`
    : `${result.created} enregistré(s), ${result.skipped} déjà connu(s).`;
  document.getElementById("results").hidden = true;
});
