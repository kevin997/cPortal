#!/usr/bin/env python3
"""
One-off icon generator for the CSL WhatsApp CRM extension.

Produces icon16.png, icon48.png, icon128.png: a solid indigo rounded
square with a white "C" centered on it. Run with:

    python3 generate_icons.py

Requires Pillow (PIL). Not loaded at runtime by the extension — this
script is a dev utility kept for regenerating the icons if needed.
"""
from PIL import Image, ImageDraw, ImageFont
import os

INDIGO = (79, 70, 229, 255)  # #4F46E5 - matches the CRM button accent
WHITE = (255, 255, 255, 255)

SIZES = (16, 48, 128)

HERE = os.path.dirname(os.path.abspath(__file__))


def make_icon(size):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    radius = max(2, size // 5)
    draw.rounded_rectangle([0, 0, size - 1, size - 1], radius=radius, fill=INDIGO)

    # Try to load a bold-ish truetype font; fall back to default bitmap font.
    font = None
    candidates = [
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
        "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    ]
    font_size = int(size * 0.62)
    for path in candidates:
        if os.path.exists(path):
            font = ImageFont.truetype(path, font_size)
            break
    if font is None:
        font = ImageFont.load_default()

    text = "C"
    bbox = draw.textbbox((0, 0), text, font=font)
    text_w = bbox[2] - bbox[0]
    text_h = bbox[3] - bbox[1]
    x = (size - text_w) / 2 - bbox[0]
    y = (size - text_h) / 2 - bbox[1]
    draw.text((x, y), text, font=font, fill=WHITE)

    return img


def main():
    for size in SIZES:
        img = make_icon(size)
        out_path = os.path.join(HERE, f"icon{size}.png")
        img.save(out_path, "PNG")
        print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
