# CSL BRANDS — extension Chrome CRM

Extension Chrome Manifest V3, installée en mode développeur ("Load unpacked").
Elle n'est **pas** publiée sur le Chrome Web Store.

Dans `web.whatsapp.com`, l'espace CSL BRANDS reste ancré à WhatsApp, détecte
automatiquement le contact de la discussion en cours (téléphone et nom), puis
l'envoie vers le système de leads CSL Automations.

## Installation

1. Ouvrir `chrome://extensions` dans Chrome (ou un navigateur basé sur
   Chromium : Edge, Brave, etc.).
2. Activer le **Mode développeur** (bouton en haut à droite).
3. Cliquer sur **"Charger l'extension non empaquetée"** ("Load unpacked").
4. Sélectionner le dossier `chrome-extension/` (ce dossier).
5. Le logo CSL BRANDS apparaît dans la barre d'outils.

## Configuration

1. Clic droit sur l'icône de l'extension → **Options** (ou via le lien
   "Ouvrir les options" dans le popup).
2. Renseigner :
   - **URL de l'API** — par défaut `https://automations.csl-brands.com`.
     Si vous utilisez une autre URL (staging, local, etc.), l'extension
     demandera une autorisation d'accès à ce domaine au moment de
     l'enregistrement ou du test (`chrome.permissions.request`).
   - **Token d'accès** — le token Bearer fourni par le backend CSL
     Automations.
3. Cliquer sur **"Tester la connexion"** pour vérifier que l'API répond
   (`GET {apiUrl}/health`, sans authentification).
4. Cliquer sur **"Enregistrer"**.

## Utilisation

1. Ouvrir `web.whatsapp.com` et sélectionner une conversation.
2. Cliquer sur le bouton rond **CRM** en bas à droite (au-dessus de la
   zone de saisie WhatsApp).
3. Un panneau s'ouvre, prérempli quand c'est possible :
   - **Nom** — extrait de l'en-tête de la conversation.
   - **Téléphone** — extrait des messages de la conversation (éditable).
   - **Produit/Service d'intérêt** — champ libre avec suggestions.
   - **Étape** — Contacté / En relance / Opportunité / Client.
   - **Notes** — libre.
4. Cliquer sur **"Enregistrer"**. Le panneau affiche :
   - `✓ Lead créé` ou `✓ Lead mis à jour (déjà connu)` en cas de succès
     (fermeture automatique après 2.5s) ;
   - un message d'erreur explicite sinon (ex : token invalide →
     configurer l'extension via les Options).
5. Pour les groupes WhatsApp (`@g.us`), le téléphone n'est pas
   détectable automatiquement — un indice "conversation de groupe"
   s'affiche et le champ **Téléphone** reste à compléter manuellement.

Le popup de la barre d'outils affiche l'état de configuration et le
nombre de leads enregistrés pendant la session en cours (navigateur
ouvert), utile pour un contrôle rapide sans ouvrir WhatsApp.

## Maintenance — le DOM de WhatsApp Web change souvent

WhatsApp Web n'a pas d'API publique et son DOM est obfusqué ; Meta modifie
régulièrement les noms de classes et la structure. Si la détection
automatique du nom ou du téléphone cesse de fonctionner (champs vides à
l'ouverture du panneau), le panneau reste utilisable : tous les champs sont
éditables manuellement, rien ne bloque l'enregistrement d'un lead.

Tous les sélecteurs utilisés pour l'extraction sont regroupés en **constantes
nommées en haut de `content.js`** :

- `SEL_APP_ROOT` — racine de l'app WhatsApp Web (détection du chargement).
- `SEL_MAIN_PANEL` — panneau de conversation actif.
- `SEL_CHAT_HEADER` — en-tête de la conversation.
- `SEL_HEADER_TITLE_SPAN` — span portant l'attribut `title` (nom du contact).
- `SEL_MESSAGE_ROWS_WITH_DATA_ID` — lignes de messages portant `data-id`.
- `RE_PHONE_FROM_DATA_ID` — regex extrayant le numéro depuis un `data-id`
  de type `..._237659xxxxxx@c.us_...`.
- `RE_GROUP_DATA_ID` — regex détectant un identifiant de groupe (`@g.us`).
- `RE_PHONE_LIKE` — regex de secours si le titre de l'en-tête ressemble
  déjà à un numéro de téléphone.

Pour corriger une régression : ouvrir les DevTools sur `web.whatsapp.com`,
inspecter l'en-tête de conversation et les lignes de messages, puis mettre
à jour uniquement ces constantes (la logique d'extraction elle-même n'a
normalement pas besoin de changer).

## Fichiers

```
chrome-extension/
├── manifest.json        Déclaration MV3 (permissions, content script, popup, options)
├── background.js         Service worker : appel réseau vers l'API (POST /api/leads)
├── content.js            Bouton flottant + extraction + panneau (injecté sur web.whatsapp.com)
├── content.css            Styles du bouton flottant et du panneau
├── options.html/options.js  Page de configuration (URL API, token, test de connexion)
├── popup.html/popup.js      Popup de la barre d'outils (statut, compteur de session)
├── icons/                  Icônes 16/48/128 (générées via icons/generate_icons.py, PIL)
└── README-extension.md      Ce fichier
```
