/**
 * background.js — MV3 service worker
 *
 * Content scripts cannot reliably make cross-origin fetches (WhatsApp Web's
 * own CSP and origin restrictions get in the way), so the actual POST to the
 * CSL automations API happens here instead. The content script just sends a
 * runtime message with the lead payload and waits for the response.
 */

const REQUEST_TIMEOUT_MS = 15000;
const LEADS_ENDPOINT_PATH = "/api/leads";
const WEB_LEADS_ENDPOINT_PATH = "/api/web-leads/bulk";

const SESSION_COUNTER_KEY = "leadsSavedThisSession";

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (!message || !["saveLead", "importGroup", "fetchServices", "postWebLeads"].includes(message.type)) {
    return false; // not for us
  }

  let operation;
  if (message.type === "saveLead") {
    operation = handleSaveLead(message.payload);
  } else if (message.type === "fetchServices") {
    operation = handleApiGet("/api/catalog/services");
  } else if (message.type === "postWebLeads") {
    operation = postWebLeads(message.items);
  } else {
    operation = handleApiPost("/api/messaging/wachap/groups/import", message.payload);
  }
  operation
    .then((result) => sendResponse(result))
    .catch((err) => {
      sendResponse({ error: err.message || "unknown_error" });
    });

  return true; // keep the message channel open for the async response
});

async function handleSaveLead(payload) {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);

  if (!apiUrl || !token) {
    return { error: "not_configured" };
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`${apiUrl.replace(/\/$/, "")}${LEADS_ENDPOINT_PATH}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    let data = null;
    try {
      data = await response.json();
    } catch (_parseErr) {
      // No/invalid JSON body — fall through with data = null.
    }

    if (!response.ok) {
      return {
        error: (data && data.detail) || (data && data.message) || `http_${response.status}`,
        status: response.status,
      };
    }

    await incrementSessionCounter();

    return {
      ok: true,
      created: data ? data.created : undefined,
      lead: data ? data.lead : undefined,
    };
  } catch (err) {
    clearTimeout(timeoutId);
    if (err.name === "AbortError") {
      return { error: "timeout" };
    }
    return { error: err.message || "network_error" };
  }
}

async function handleApiPost(path, payload) {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  if (!apiUrl || !token) return { error: "not_configured" };
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 45000);
  try {
    const response = await fetch(`${apiUrl.replace(/\/$/, "")}${path}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(payload),
      signal: controller.signal,
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) return { error: data?.detail || `http_${response.status}`, status: response.status };
    return data;
  } catch (err) {
    return { error: err.name === "AbortError" ? "timeout" : err.message || "network_error" };
  } finally {
    clearTimeout(timeoutId);
  }
}

async function handleApiGet(path) {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  if (!apiUrl || !token) return { error: "not_configured" };
  const controller = new AbortController();
  // Shorter than the POST timeout: this only feeds a dropdown, and the panel
  // falls back to its bundled list rather than waiting on a slow network.
  const timeoutId = setTimeout(() => controller.abort(), 15000);
  try {
    const response = await fetch(`${apiUrl.replace(/\/$/, "")}${path}`, {
      method: "GET",
      headers: { Authorization: `Bearer ${token}` },
      signal: controller.signal,
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) return { error: data?.detail || `http_${response.status}`, status: response.status };
    return data;
  } catch (err) {
    return { error: err.name === "AbortError" ? "timeout" : err.message || "network_error" };
  } finally {
    clearTimeout(timeoutId);
  }
}

async function postWebLeads(items) {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  if (!apiUrl || !token) return { error: "not_configured" };

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const response = await fetch(`${apiUrl.replace(/\/$/, "")}${WEB_LEADS_ENDPOINT_PATH}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ items }),
      signal: controller.signal,
    });
    const data = await response.json().catch(() => null);
    if (!response.ok) return { error: "request_failed", status: response.status };
    return { ok: true, created: data?.created ?? 0, skipped: data?.skipped ?? 0 };
  } catch (error) {
    // A stalled connection must surface as an error, not leave the popup
    // waiting forever.
    if (error.name === "AbortError") return { error: "timeout" };
    return { error: "network", message: String(error) };
  } finally {
    clearTimeout(timeoutId);
  }
}

async function incrementSessionCounter() {
  const { [SESSION_COUNTER_KEY]: current } = await chrome.storage.local.get(SESSION_COUNTER_KEY);
  await chrome.storage.local.set({ [SESSION_COUNTER_KEY]: (current || 0) + 1 });
}
