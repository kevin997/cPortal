/**
 * popup.js — small status popup shown from the toolbar icon.
 */

const SESSION_COUNTER_KEY = "leadsSavedThisSession";

document.addEventListener("DOMContentLoaded", init);
document.getElementById("optionsLink").addEventListener("click", (e) => {
  e.preventDefault();
  chrome.runtime.openOptionsPage();
});

async function init() {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  const configured = Boolean(apiUrl && token);

  const dot = document.getElementById("statusDot");
  const text = document.getElementById("statusText");

  if (configured) {
    dot.className = "dot dot-ok";
    text.textContent = "Configuré";
  } else {
    dot.className = "dot dot-off";
    text.textContent = "Non configuré";
  }

  const { [SESSION_COUNTER_KEY]: count } = await chrome.storage.local.get(SESSION_COUNTER_KEY);
  document.getElementById("countText").textContent = `${count || 0} lead(s) enregistré(s) cette session`;
}
