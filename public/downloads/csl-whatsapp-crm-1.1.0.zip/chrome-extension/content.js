/**
 * content.js — injected into https://web.whatsapp.com/*
 *
 * Adds a floating "CRM" button. On click, it extracts the currently open
 * chat's name/phone using layered, best-effort strategies against
 * WhatsApp Web's obfuscated DOM, then opens a small overlay form so the
 * user can confirm/edit the details before saving the lead.
 *
 * MAINTENANCE NOTE: WhatsApp Web changes its DOM/class names often. All
 * CSS selectors used for extraction are named constants right below —
 * if capture stops working, this is the first place to look. The panel
 * always allows manual entry as a fallback, so extraction failures never
 * block the user from saving a lead.
 */

// ---------------------------------------------------------------------------
// Selector constants (update here if WhatsApp Web's DOM changes)
// ---------------------------------------------------------------------------

// WhatsApp Web's root app container — used to detect that the SPA has booted.
const SEL_APP_ROOT = "#app";

// The main conversation panel (right-hand pane showing the open chat).
const SEL_MAIN_PANEL = "#main";

// Header of the open conversation, inside the main panel.
const SEL_CHAT_HEADER = "#main header";

// Inside the header, the contact/group title is rendered as a span with a
// `title` attribute (WhatsApp uses `title` for the full name, since the
// visible text may be truncated with ellipsis).
const SEL_HEADER_TITLE_SPAN = "span[title]";

// Message rows inside the open conversation carry a `data-id` attribute
// encoding direction + the other party's WhatsApp ID, e.g.:
//   "false_237659xxxxxx@c.us_3EB0...."   (incoming)
//   "true_237659xxxxxx@c.us_3EB0....."   (outgoing)
// Group chats use "@g.us" instead of "@c.us" and don't carry a usable phone.
const SEL_MESSAGE_ROWS_WITH_DATA_ID = "#main [data-id]";

// Regex to pull the phone number out of a c.us data-id.
const RE_PHONE_FROM_DATA_ID = /_(\d{6,15})@c\.us/;

// Regex to detect a group chat data-id (no directly usable phone).
const RE_GROUP_DATA_ID = /@g\.us/;

// Fallback: some chat headers show the phone number itself as the title
// (e.g. contact not saved), matched against a loose phone-like pattern.
const RE_PHONE_LIKE = /^\+?[\d\s-]{8,}$/;

// ---------------------------------------------------------------------------
// Floating action button
// ---------------------------------------------------------------------------

const FAB_ID = "csl-crm-fab";
const PANEL_ID = "csl-crm-panel";
const PANEL_BACKDROP_ID = "csl-crm-backdrop";

const PRODUCT_SUGGESTIONS = [
  "Formation Marketing Digital",
  "KURSA",
  "Création site web",
  "Création application",
  "Community Management",
  "Identité visuelle",
  "Pub en ligne",
];

const STAGE_OPTIONS = [
  { value: "contacted", label: "Contacté" },
  { value: "nurturing", label: "En relance" },
  { value: "opportunity", label: "Opportunité" },
  { value: "customer", label: "Client" },
];

function waitForWhatsAppReady() {
  const POLL_INTERVAL_MS = 1000;

  const interval = setInterval(() => {
    const appRoot = document.querySelector(SEL_APP_ROOT);
    if (appRoot && appRoot.childElementCount > 0) {
      clearInterval(interval);
      injectFab();
    }
  }, POLL_INTERVAL_MS);
}

function injectFab() {
  if (document.getElementById(FAB_ID)) {
    return; // already injected
  }

  const fab = document.createElement("button");
  fab.id = FAB_ID;
  fab.type = "button";
  fab.textContent = "CRM";
  fab.title = "Capturer ce contact dans le CRM CSL";
  fab.addEventListener("click", onFabClick);

  document.body.appendChild(fab);
}

function onFabClick() {
  const extracted = extractCurrentChatInfo();
  openPanel(extracted);
}

// ---------------------------------------------------------------------------
// Extraction (run once, at click time — no MutationObserver)
// ---------------------------------------------------------------------------

function extractCurrentChatInfo() {
  const name = extractName();
  const { phone, isGroup } = extractPhone();

  // Fallback: if no name was found but the header title itself looks like a
  // phone number, and we don't already have a phone, use it as both hints.
  let finalPhone = phone;
  if (!finalPhone && name && RE_PHONE_LIKE.test(name)) {
    finalPhone = name;
  }

  return { name: name || "", phone: finalPhone || "", isGroup };
}

function extractName() {
  const header = document.querySelector(SEL_CHAT_HEADER);
  if (!header) return "";

  const titleSpan = header.querySelector(SEL_HEADER_TITLE_SPAN);
  if (titleSpan && titleSpan.getAttribute("title")) {
    return titleSpan.getAttribute("title").trim();
  }

  return "";
}

function extractPhone() {
  const rows = document.querySelectorAll(SEL_MESSAGE_ROWS_WITH_DATA_ID);
  if (!rows || rows.length === 0) {
    return { phone: "", isGroup: false };
  }

  let sawGroupId = false;

  // Walk from the last message backwards looking for a usable @c.us id.
  for (let i = rows.length - 1; i >= 0; i--) {
    const dataId = rows[i].getAttribute("data-id") || "";

    if (RE_GROUP_DATA_ID.test(dataId)) {
      sawGroupId = true;
      continue;
    }

    const match = dataId.match(RE_PHONE_FROM_DATA_ID);
    if (match) {
      return { phone: match[1], isGroup: false };
    }
  }

  return { phone: "", isGroup: sawGroupId };
}

// ---------------------------------------------------------------------------
// Overlay panel
// ---------------------------------------------------------------------------

function openPanel(extracted) {
  closePanel(); // ensure no duplicate panel

  const backdrop = document.createElement("div");
  backdrop.id = PANEL_BACKDROP_ID;
  backdrop.addEventListener("click", closePanel);

  const panel = document.createElement("div");
  panel.id = PANEL_ID;
  // Prevent clicks inside the panel from bubbling to the backdrop and closing it.
  panel.addEventListener("click", (e) => e.stopPropagation());

  panel.innerHTML = buildPanelHtml(extracted);
  document.body.appendChild(backdrop);
  document.body.appendChild(panel);

  panel.querySelector("#csl-crm-close").addEventListener("click", closePanel);
  panel.querySelector("#csl-crm-form").addEventListener("submit", onSubmit);

  if (extracted.isGroup && !extracted.phone) {
    showHint(panel, "Conversation de groupe : téléphone inconnu, à renseigner manuellement.");
  }
}

function closePanel() {
  const existingPanel = document.getElementById(PANEL_ID);
  const existingBackdrop = document.getElementById(PANEL_BACKDROP_ID);
  if (existingPanel) existingPanel.remove();
  if (existingBackdrop) existingBackdrop.remove();
}

function buildPanelHtml(extracted) {
  const datalistOptions = PRODUCT_SUGGESTIONS.map((p) => `<option value="${escapeHtml(p)}"></option>`).join("");
  const stageOptions = STAGE_OPTIONS.map(
    (s) => `<option value="${s.value}"${s.value === "contacted" ? " selected" : ""}>${s.label}</option>`
  ).join("");

  return `
    <div class="csl-crm-panel-header">
      <div>
        <strong>Fiche contact CSL</strong>
        <small>Qualifier sans quitter WhatsApp</small>
      </div>
      <button type="button" id="csl-crm-close" aria-label="Fermer">&times;</button>
    </div>
    <form id="csl-crm-form" class="csl-crm-panel-body">
      <div id="csl-crm-hint" class="csl-crm-hint" hidden></div>

      <fieldset class="csl-crm-section">
        <legend>Contact</legend>
        <div class="csl-crm-grid">
          <div>
            <label class="csl-crm-label" for="csl-crm-name">Nom</label>
            <input class="csl-crm-input" type="text" id="csl-crm-name" value="${escapeHtml(extracted.name)}" autocomplete="name" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-phone">Téléphone</label>
            <input class="csl-crm-input" type="tel" id="csl-crm-phone" value="${escapeHtml(extracted.phone)}" required autocomplete="tel" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-email">E-mail</label>
            <input class="csl-crm-input" type="email" id="csl-crm-email" autocomplete="email" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-company">Entreprise</label>
            <input class="csl-crm-input" type="text" id="csl-crm-company" autocomplete="organization" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-city">Ville</label>
            <input class="csl-crm-input" type="text" id="csl-crm-city" autocomplete="address-level2" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-country">Pays</label>
            <input class="csl-crm-input" type="text" id="csl-crm-country" autocomplete="country-name" />
          </div>
        </div>
      </fieldset>

      <fieldset class="csl-crm-section">
        <legend>Qualification</legend>
        <label class="csl-crm-label" for="csl-crm-product">Produit ou service recherché</label>
        <input class="csl-crm-input" type="text" id="csl-crm-product" list="csl-crm-product-list" />
        <datalist id="csl-crm-product-list">${datalistOptions}</datalist>

        <div class="csl-crm-grid">
          <div>
            <label class="csl-crm-label" for="csl-crm-stage">Étape</label>
            <select class="csl-crm-input" id="csl-crm-stage">${stageOptions}</select>
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-value">Valeur estimée (FCFA)</label>
            <input class="csl-crm-input" type="number" min="0" step="1000" id="csl-crm-value" inputmode="numeric" />
          </div>
        </div>

        <label class="csl-crm-label" for="csl-crm-followup">Prochaine relance</label>
        <input class="csl-crm-input" type="date" id="csl-crm-followup" />

        <label class="csl-crm-label" for="csl-crm-notes">Contexte et prochaine action</label>
        <textarea class="csl-crm-input" id="csl-crm-notes" rows="3" placeholder="Besoin, objection, décision attendue…"></textarea>

        <label class="csl-crm-consent" for="csl-crm-contactable">
          <input type="checkbox" id="csl-crm-contactable" checked />
          <span>Ce contact accepte d'être recontacté</span>
        </label>
      </fieldset>

      <div class="csl-crm-actions">
        <button type="submit" id="csl-crm-save" class="csl-crm-btn-primary">Enregistrer</button>
      </div>

      <div id="csl-crm-status" class="csl-crm-status" hidden></div>
    </form>
  `;
}

function showHint(panel, text) {
  const hint = panel.querySelector("#csl-crm-hint");
  hint.textContent = text;
  hint.hidden = false;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function onSubmit(e) {
  e.preventDefault();

  const panel = document.getElementById(PANEL_ID);
  const saveBtn = panel.querySelector("#csl-crm-save");
  const statusEl = panel.querySelector("#csl-crm-status");

  const payload = {
    phone: panel.querySelector("#csl-crm-phone").value.trim(),
    name: panel.querySelector("#csl-crm-name").value.trim() || undefined,
    email: panel.querySelector("#csl-crm-email").value.trim() || undefined,
    company: panel.querySelector("#csl-crm-company").value.trim() || undefined,
    city: panel.querySelector("#csl-crm-city").value.trim() || undefined,
    country: panel.querySelector("#csl-crm-country").value.trim() || undefined,
    product_interest: panel.querySelector("#csl-crm-product").value.trim() || undefined,
    value_fcfa: Number(panel.querySelector("#csl-crm-value").value) || undefined,
    next_followup_at: panel.querySelector("#csl-crm-followup").value || undefined,
    opt_out: !panel.querySelector("#csl-crm-contactable").checked,
    stage: panel.querySelector("#csl-crm-stage").value,
    notes: panel.querySelector("#csl-crm-notes").value.trim() || undefined,
    source: "whatsapp-crm",
  };

  if (!payload.phone) {
    setStatus(statusEl, "error", "Le téléphone est requis.");
    return;
  }

  saveBtn.disabled = true;
  saveBtn.textContent = "Enregistrement...";

  chrome.runtime.sendMessage({ type: "saveLead", payload }, (response) => {
    saveBtn.disabled = false;
    saveBtn.textContent = "Enregistrer";

    if (chrome.runtime.lastError) {
      setStatus(statusEl, "error", "Erreur d'extension : " + chrome.runtime.lastError.message);
      return;
    }

    if (!response || response.error) {
      setStatus(statusEl, "error", describeError(response && response.error, response && response.status));
      return;
    }

    const stageLabel =
      (STAGE_OPTIONS.find((s) => s.value === (response.lead && response.lead.stage)) || {}).label ||
      payload.stage;

    const message = response.created ? "✓ Lead créé" : "✓ Lead mis à jour (déjà connu)";
    setStatus(statusEl, "success", `${message} — étape : ${stageLabel}`);

    setTimeout(closePanel, 2500);
  });
}

function describeError(error, status) {
  if (error === "not_configured") {
    return "Extension non configurée — clic droit sur l'icône → Options.";
  }
  if (status === 401 || error === "http_401") {
    return "Token invalide — configurez l'extension (clic droit sur l'icône → Options).";
  }
  if (error === "timeout") {
    return "Le serveur ne répond pas (délai dépassé).";
  }
  if (error === "network_error") {
    return "Erreur réseau — vérifiez votre connexion.";
  }
  return `Erreur : ${error || "inconnue"}`;
}

function setStatus(statusEl, kind, text) {
  statusEl.hidden = false;
  statusEl.className = `csl-crm-status csl-crm-status-${kind}`;
  statusEl.textContent = text;
}

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------

waitForWhatsAppReady();
