/**
 * options.js — settings page logic for Eshu WhatsApp CRM.
 */

const DEFAULT_API_URL = "https://automations.csl-brands.com";

const apiUrlInput = document.getElementById("apiUrl");
const tokenInput = document.getElementById("token");
const saveBtn = document.getElementById("save");
const testBtn = document.getElementById("test");
const statusEl = document.getElementById("status");

document.addEventListener("DOMContentLoaded", loadSettings);
saveBtn.addEventListener("click", onSave);
testBtn.addEventListener("click", onTest);

async function loadSettings() {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  apiUrlInput.value = apiUrl || DEFAULT_API_URL;
  tokenInput.value = token || "";
}

async function onSave() {
  const apiUrl = normalizeUrl(apiUrlInput.value.trim() || DEFAULT_API_URL);
  const token = tokenInput.value.trim();

  if (apiUrl !== DEFAULT_API_URL) {
    const granted = await requestHostPermission(apiUrl);
    if (!granted) {
      showStatus("error", "Permission refusée pour ce domaine — l'API personnalisée ne pourra pas être appelée.");
      return;
    }
  }

  await chrome.storage.sync.set({ apiUrl, token });
  showStatus("success", "Paramètres enregistrés.");
}

async function onTest() {
  const apiUrl = normalizeUrl(apiUrlInput.value.trim() || DEFAULT_API_URL);

  if (apiUrl !== DEFAULT_API_URL) {
    const granted = await requestHostPermission(apiUrl);
    if (!granted) {
      showStatus("error", "Permission refusée pour ce domaine.");
      return;
    }
  }

  showStatus("success", "Test en cours...");

  try {
    const response = await fetch(`${apiUrl}/health`);
    if (response.ok) {
      showStatus("success", "Connexion réussie.");
    } else {
      showStatus("error", `Échec (HTTP ${response.status}).`);
    }
  } catch (err) {
    showStatus("error", `Échec de connexion : ${err.message}`);
  }
}

async function requestHostPermission(apiUrl) {
  try {
    const origin = new URL(apiUrl).origin + "/*";
    return await chrome.permissions.request({ origins: [origin] });
  } catch (err) {
    return false;
  }
}

function normalizeUrl(url) {
  return url.replace(/\/$/, "");
}

function showStatus(kind, text) {
  statusEl.style.display = "block";
  statusEl.className = `status-${kind}`;
  statusEl.textContent = text;
}
