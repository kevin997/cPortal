#!/usr/bin/env python3
"""
One-off icon generator for the CSL BRANDS extension.

Rasterizes the canonical csl-crm-mark.svg into Chrome's required PNG sizes. Run with:

    python3 generate_icons.py

Requires Pillow (PIL). Not loaded at runtime by the extension — this
script is a dev utility kept for regenerating the icons if needed.
"""
import os
import subprocess

SIZES = (16, 48, 128)

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    source = os.path.join(HERE, "csl-crm-mark.svg")
    for size in SIZES:
        out_path = os.path.join(HERE, f"icon{size}.png")
        subprocess.run(
            [
                "google-chrome",
                "--headless",
                "--disable-gpu",
                "--hide-scrollbars",
                f"--window-size={size},{size}",
                f"--screenshot={out_path}",
                source,
            ],
            check=True,
            stdout=subprocess.DEVNULL,
        )
        print(f"wrote {out_path}")


if __name__ == "__main__":
    main()
