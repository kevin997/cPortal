/**
 * options.js — settings page logic for Eshu WhatsApp CRM.
 */

const DEFAULT_API_URL = "https://automations.csl-brands.com";

const apiUrlInput = document.getElementById("apiUrl");
const tokenInput = document.getElementById("token");
const saveBtn = document.getElementById("save");
const testBtn = document.getElementById("test");
const statusEl = document.getElementById("status");

document.addEventListener("DOMContentLoaded", loadSettings);
saveBtn.addEventListener("click", onSave);
testBtn.addEventListener("click", onTest);

async function loadSettings() {
  const { apiUrl, token } = await chrome.storage.sync.get(["apiUrl", "token"]);
  apiUrlInput.value = apiUrl || DEFAULT_API_URL;
  tokenInput.value = token || "";

  // Which copy am I configuring? With two installs, settings saved here may
  // belong to the copy that is NOT rendering the panel on WhatsApp Web.
  const version = chrome.runtime.getManifest().version;
  const badge = document.getElementById("version");
  if (badge) badge.textContent = `Version ${version}`;
  if (!token) {
    showStatus("error", "Aucun jeton enregistre pour cette copie de l'extension.");
  }
}

async function onSave() {
  const apiUrl = normalizeUrl(apiUrlInput.value.trim() || DEFAULT_API_URL);
  const token = tokenInput.value.trim();

  if (apiUrl !== DEFAULT_API_URL) {
    const granted = await requestHostPermission(apiUrl);
    if (!granted) {
      showStatus("error", "Permission refusée pour ce domaine — l'API personnalisée ne pourra pas être appelée.");
      return;
    }
  }

  await chrome.storage.sync.set({ apiUrl, token });
  showStatus("success", "Paramètres enregistrés.");
}

async function onTest() {
  const apiUrl = normalizeUrl(apiUrlInput.value.trim() || DEFAULT_API_URL);

  if (apiUrl !== DEFAULT_API_URL) {
    const granted = await requestHostPermission(apiUrl);
    if (!granted) {
      showStatus("error", "Permission refusée pour ce domaine.");
      return;
    }
  }

  const token = tokenInput.value.trim();
  if (!token) {
    showStatus("error", "Saisissez d'abord le jeton.");
    return;
  }

  // Save before testing. This button used to test without saving, so a user
  // could type a token, see "Connexion réussie" and close the page with
  // nothing stored -- the panel then reported "Extension non configurée".
  await chrome.storage.sync.set({ apiUrl, token });

  showStatus("success", "Test en cours...");

  try {
    // An authenticated endpoint, not /health: /health needs no token, so it
    // answered 200 for any value typed here, including a wrong one.
    const response = await fetch(`${apiUrl}/api/catalog/services`, {
      headers: { Authorization: `Bearer ${token}` },
    });
    if (response.ok) {
      const data = await response.json().catch(() => null);
      const count = Array.isArray(data?.services) ? data.services.length : 0;
      showStatus("success", `Connexion réussie — paramètres enregistrés, ${count} service(s) disponible(s).`);
    } else if (response.status === 401) {
      showStatus("error", "Jeton refusé (401). Vérifiez la valeur copiée.");
    } else {
      showStatus("error", `Échec (HTTP ${response.status}).`);
    }
  } catch (err) {
    showStatus("error", `Échec de connexion : ${err.message}`);
  }
}

async function requestHostPermission(apiUrl) {
  try {
    const origin = new URL(apiUrl).origin + "/*";
    return await chrome.permissions.request({ origins: [origin] });
  } catch (err) {
    return false;
  }
}

function normalizeUrl(url) {
  return url.replace(/\/$/, "");
}

function showStatus(kind, text) {
  statusEl.style.display = "block";
  statusEl.className = `status-${kind}`;
  statusEl.textContent = text;
}
