/**
 * content.js — injected into https://web.whatsapp.com/*
 *
 * Adds a floating "CRM" button. On click, it extracts the currently open
 * chat's name/phone using layered, best-effort strategies against
 * WhatsApp Web's obfuscated DOM, then opens a small overlay form so the
 * user can confirm/edit the details before saving the lead.
 *
 * MAINTENANCE NOTE: WhatsApp Web changes its DOM/class names often. All
 * CSS selectors used for extraction are named constants right below —
 * if capture stops working, this is the first place to look. The panel
 * always allows manual entry as a fallback, so extraction failures never
 * block the user from saving a lead.
 */

// ---------------------------------------------------------------------------
// Selector constants (update here if WhatsApp Web's DOM changes)
// ---------------------------------------------------------------------------

// WhatsApp Web's root app container — used to detect that the SPA has booted.
const SEL_APP_ROOT = "#app";

// The main conversation panel (right-hand pane showing the open chat).
const SEL_MAIN_PANEL = "#main";

// Header of the open conversation, inside the main panel.
const SEL_CHAT_HEADER = "#main header";

const SEL_HEADER_IDENTITY_CANDIDATES = "[data-testid='conversation-info-header-chat-title'], span[title], [dir='auto']";

// Message rows inside the open conversation carry a `data-id` attribute
// encoding direction + the other party's WhatsApp ID, e.g.:
//   "false_237659xxxxxx@c.us_3EB0...."   (incoming)
//   "true_237659xxxxxx@c.us_3EB0....."   (outgoing)
// Group chats use "@g.us" instead of "@c.us" and don't carry a usable phone.
const SEL_MESSAGE_ROWS_WITH_DATA_ID = "#main [data-id]";

// Regex to pull the phone number out of a c.us data-id.
const RE_PHONE_FROM_WA_ID = /(?:^|[^\d])(\d{7,15})@(?:c\.us|s\.whatsapp\.net)(?:[^\d]|$)/;

// Regex to detect a group chat data-id (no directly usable phone).
const RE_GROUP_DATA_ID = /@g\.us/;
const RE_GROUP_JID = /([0-9-]+@g\.us)/;

// Fallback: some chat headers show the phone number itself as the title
// (e.g. contact not saved), matched against a loose phone-like pattern.
const RE_PHONE_LIKE = /\+?[\d][\d\s().-]{6,}[\d]/;
const REJECTED_IDENTITY_TEXT = /^(online|typing…?|typing\.\.\.|last seen|click here for contact info|en ligne|écrit…?|vu à|business account|compte professionnel)$/i;

// ---------------------------------------------------------------------------
// Floating action button
// ---------------------------------------------------------------------------

const FAB_ID = "csl-crm-tab";
const PANEL_ID = "csl-crm-panel";
const APP_DOCKED_CLASS = "csl-crm-is-docked";
const PANEL_OPEN_KEY = "cslCrmPanelOpen";
let currentChatKey = "";
let chatObserver = null;
let refreshTimer = null;

const PRODUCT_SUGGESTIONS = [
  "E-commerce",
  "Marketing digital & E-commerce",
  "Formation Marketing Digital",
  "KURSA",
  "Création site web",
  "Création application",
  "Community Management",
  "Identité visuelle",
  "Pub en ligne",
];

const STAGE_OPTIONS = [
  { value: "contacted", label: "Contacté" },
  { value: "nurturing", label: "En relance" },
  { value: "opportunity", label: "Opportunité" },
  { value: "customer", label: "Client" },
];

function waitForWhatsAppReady() {
  const POLL_INTERVAL_MS = 1000;

  const interval = setInterval(() => {
    const appRoot = document.querySelector(SEL_APP_ROOT);
    if (appRoot && appRoot.childElementCount > 0) {
      clearInterval(interval);
      injectWorkspace();
    }
  }, POLL_INTERVAL_MS);
}

async function injectWorkspace() {
  if (document.getElementById(FAB_ID)) {
    return; // already injected
  }

  const tab = document.createElement("button");
  tab.id = FAB_ID;
  tab.type = "button";
  tab.innerHTML = `<img src="${chrome.runtime.getURL("icons/csl-crm-mark.svg")}" alt="" /><strong>CRM</strong>`;
  tab.title = "Ouvrir Eshu WhatsApp CRM";
  tab.setAttribute("aria-label", "Ouvrir Eshu WhatsApp CRM");
  tab.addEventListener("click", () => openPanel(extractCurrentChatInfo()));
  document.body.appendChild(tab);

  const { [PANEL_OPEN_KEY]: storedOpen } = await chrome.storage.local.get(PANEL_OPEN_KEY);
  if (storedOpen !== false) openPanel(extractCurrentChatInfo());
  observeCurrentChat();
}

// ---------------------------------------------------------------------------
// Extraction (run once, at click time — no MutationObserver)
// ---------------------------------------------------------------------------

function extractCurrentChatInfo() {
  const name = extractName();
  const { phone, isGroup } = extractPhone();
  const groupJid = isGroup ? extractGroupJid() : "";

  // Fallback: if no name was found but the header title itself looks like a
  // phone number, and we don't already have a phone, use it as both hints.
  let finalPhone = phone;
  if (!finalPhone && name && RE_PHONE_LIKE.test(name)) {
    finalPhone = name;
  }

  if (finalPhone) finalPhone = normalizeCapturedPhone(finalPhone);
  const finalName = name && !RE_PHONE_LIKE.test(name) ? name : "";
  return { name: finalName, phone: finalPhone || "", isGroup, groupJid };
}

function extractGroupJid() {
  const rows = document.querySelectorAll(SEL_MESSAGE_ROWS_WITH_DATA_ID);
  for (let index = rows.length - 1; index >= 0; index--) {
    const match = (rows[index].getAttribute("data-id") || "").match(RE_GROUP_JID);
    if (match) return match[1];
  }
  return "";
}

function extractName() {
  const header = document.querySelector(SEL_CHAT_HEADER);
  if (!header) return "";
  const candidates = [];
  header.querySelectorAll(SEL_HEADER_IDENTITY_CANDIDATES).forEach((element) => {
    const title = (element.getAttribute("title") || "").trim();
    const text = (element.textContent || "").trim();
    if (title) candidates.push(title);
    if (text && text !== title) candidates.push(text);
  });
  return candidates
    .map((value) => value.replace(/\s+/g, " ").trim())
    .find((value) => value && value.length <= 120 && !REJECTED_IDENTITY_TEXT.test(value)) || "";
}

function extractPhone() {
  const rows = document.querySelectorAll(SEL_MESSAGE_ROWS_WITH_DATA_ID);
  let sawGroupId = false;

  // Walk from the last message backwards looking for a usable @c.us id.
  for (let i = rows.length - 1; i >= 0; i--) {
    const dataId = rows[i].getAttribute("data-id") || "";

    if (RE_GROUP_DATA_ID.test(dataId)) {
      sawGroupId = true;
      continue;
    }

    const match = dataId.match(RE_PHONE_FROM_WA_ID);
    if (match) {
      return { phone: match[1], isGroup: false };
    }
  }

  const infoPhone = extractPhoneFromContactInfo();
  if (infoPhone) return { phone: infoPhone, isGroup: sawGroupId };

  const header = document.querySelector(SEL_CHAT_HEADER);
  const headerText = header ? header.textContent || "" : "";
  const headerPhone = headerText.match(RE_PHONE_LIKE);
  return { phone: headerPhone ? headerPhone[0] : "", isGroup: sawGroupId };
}

function extractPhoneFromContactInfo() {
  const main = document.querySelector(SEL_MAIN_PANEL);
  const candidates = [];

  document.querySelectorAll("[role='button'], [title], [aria-label], span, div").forEach((element) => {
    if (main && main.contains(element)) return;
    if (!isVisible(element)) return;

    const values = [
      element.getAttribute("title") || "",
      element.getAttribute("aria-label") || "",
      element.childElementCount === 0 ? element.textContent || "" : "",
    ];

    values.forEach((rawValue) => {
      const value = rawValue.replace(/\s+/g, " ").trim();
      const match = value.match(RE_PHONE_LIKE);
      if (!match || match[0].replace(/\D/g, "").length < 7) return;
      const rect = element.getBoundingClientRect();
      candidates.push({ phone: match[0], x: rect.left, exact: value === match[0] });
    });
  });

  candidates.sort((a, b) => Number(b.exact) - Number(a.exact) || b.x - a.x);
  return candidates[0] ? candidates[0].phone : "";
}

function isVisible(element) {
  const rect = element.getBoundingClientRect();
  const style = window.getComputedStyle(element);
  return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none";
}

function normalizeCapturedPhone(value) {
  const compact = value.replace(/[^\d+]/g, "");
  return compact.startsWith("+") ? compact : `+${compact}`;
}

function observeCurrentChat() {
  if (chatObserver) chatObserver.disconnect();
  chatObserver = new MutationObserver(() => {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refreshPanelForCurrentChat, 180);
  });
  chatObserver.observe(document.querySelector(SEL_APP_ROOT), { childList: true, subtree: true });
}

function refreshPanelForCurrentChat() {
  const extracted = extractCurrentChatInfo();
  const chatKey = `${extracted.phone}|${extracted.name}`;
  if (!chatKey || chatKey === "|" || chatKey === currentChatKey) return;
  currentChatKey = chatKey;
  const panel = document.getElementById(PANEL_ID);
  if (!panel) return;
  const form = panel.querySelector("#csl-crm-form");
  if (form && form.dataset.dirty === "true") {
    showHint(panel, "Nouvelle conversation détectée. Fermez puis rouvrez la fiche pour éviter de perdre vos modifications.");
    return;
  }
  populateIdentity(panel, extracted);
}

// ---------------------------------------------------------------------------
// Overlay panel
// ---------------------------------------------------------------------------

function openPanel(extracted) {
  const existing = document.getElementById(PANEL_ID);
  if (existing) {
    populateIdentity(existing, extracted);
    return;
  }

  const panel = document.createElement("div");
  panel.id = PANEL_ID;
  panel.innerHTML = buildPanelHtml(extracted);
  document.body.appendChild(panel);
  document.documentElement.classList.add(APP_DOCKED_CLASS);
  document.getElementById(FAB_ID).hidden = true;
  currentChatKey = `${extracted.phone}|${extracted.name}`;
  chrome.storage.local.set({ [PANEL_OPEN_KEY]: true });

  panel.querySelector("#csl-crm-close").addEventListener("click", closePanel);
  panel.querySelector("#csl-crm-form").addEventListener("submit", onSubmit);
  initializeSearchableDropdowns(panel);
  panel.querySelector("#csl-crm-form").addEventListener("input", (event) => {
    if (!event.isTrusted) return;
    event.currentTarget.dataset.dirty = "true";
  });
  const groupButton = panel.querySelector("#csl-crm-group-preview");
  if (groupButton) groupButton.addEventListener("click", previewGroupImport);

  if (extracted.isGroup && !extracted.groupJid) {
    showHint(panel, "Identifiant du groupe non détecté. Ouvrez quelques messages du groupe puis réessayez.");
  }
}

function closePanel() {
  const existingPanel = document.getElementById(PANEL_ID);
  if (existingPanel) existingPanel.remove();
  document.documentElement.classList.remove(APP_DOCKED_CLASS);
  const tab = document.getElementById(FAB_ID);
  if (tab) tab.hidden = false;
  chrome.storage.local.set({ [PANEL_OPEN_KEY]: false });
}

function populateIdentity(panel, extracted) {
  const nameInput = panel.querySelector("#csl-crm-name");
  const phoneInput = panel.querySelector("#csl-crm-phone");
  if (nameInput) nameInput.value = extracted.name || "";
  if (phoneInput) phoneInput.value = extracted.phone || "";
  const identity = panel.querySelector("#csl-crm-current-contact");
  if (identity) {
    identity.querySelector("strong").textContent = extracted.name || extracted.phone || "Conversation ouverte";
    identity.querySelector("small").textContent = extracted.phone || "Numéro non détecté";
  }
  const form = panel.querySelector("#csl-crm-form");
  if (form) form.dataset.dirty = "false";
  const groupSection = panel.querySelector("#csl-crm-group-import");
  if (groupSection) {
    groupSection.hidden = !extracted.isGroup;
    groupSection.dataset.groupJid = extracted.groupJid || "";
    groupSection.dataset.groupName = extracted.name || "Groupe WhatsApp";
    const groupName = groupSection.querySelector("strong");
    const groupJid = groupSection.querySelector("small");
    if (groupName) groupName.textContent = extracted.name || "Groupe WhatsApp";
    if (groupJid) groupJid.textContent = extracted.groupJid || "Identifiant non détecté";
  }
}

function buildPanelHtml(extracted) {
  const productOptions = buildSearchableOptions(PRODUCT_SUGGESTIONS.map((label) => ({ value: label, label })));
  const stageOptions = buildSearchableOptions(STAGE_OPTIONS);

  return `
    <div class="csl-crm-panel-header">
      <div class="csl-crm-brand">
        <img src="${chrome.runtime.getURL("icons/csl-crm-mark.svg")}" alt="" />
        <span><strong>Eshu WhatsApp CRM</strong>
        <small>CRM WhatsApp &amp; fidélisation</small></span>
      </div>
      <button type="button" id="csl-crm-close" aria-label="Fermer">&times;</button>
    </div>
    <div id="csl-crm-current-contact" class="csl-crm-current-contact">
      <span class="csl-crm-avatar" aria-hidden="true">${escapeHtml((extracted.name || "C").charAt(0).toUpperCase())}</span>
      <span><strong>${escapeHtml(extracted.name || extracted.phone || "Conversation ouverte")}</strong><small>${escapeHtml(extracted.phone || "Numéro non détecté")}</small></span>
      <span class="csl-crm-live">Synchronisé</span>
    </div>
    <form id="csl-crm-form" class="csl-crm-panel-body">
      <div id="csl-crm-hint" class="csl-crm-hint" hidden></div>

      <section id="csl-crm-group-import" class="csl-crm-group-import" data-group-jid="${escapeHtml(extracted.groupJid || "")}" data-group-name="${escapeHtml(extracted.name || "Groupe WhatsApp")}" ${extracted.isGroup ? "" : "hidden"}>
        <div><strong>${escapeHtml(extracted.name || "Groupe WhatsApp")}</strong><small>${escapeHtml(extracted.groupJid || "Identifiant non détecté")}</small></div>
        <p>Importez les membres dans le CRM. Les nouveaux contacts resteront sans autorisation marketing jusqu'à validation individuelle.</p>
        <button type="button" id="csl-crm-group-preview" class="csl-crm-btn-secondary" ${extracted.groupJid ? "" : "disabled"}>Prévisualiser les membres</button>
        <div id="csl-crm-group-result" class="csl-crm-status" hidden></div>
      </section>

      <fieldset class="csl-crm-section">
        <legend>Contact</legend>
        <div class="csl-crm-grid">
          <div>
            <label class="csl-crm-label" for="csl-crm-name">Nom</label>
            <input class="csl-crm-input" type="text" id="csl-crm-name" value="${escapeHtml(extracted.name)}" autocomplete="name" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-phone">Téléphone</label>
            <input class="csl-crm-input" type="tel" id="csl-crm-phone" value="${escapeHtml(extracted.phone)}" required autocomplete="tel" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-email">E-mail</label>
            <input class="csl-crm-input" type="email" id="csl-crm-email" autocomplete="email" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-company">Entreprise</label>
            <input class="csl-crm-input" type="text" id="csl-crm-company" autocomplete="organization" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-city">Ville</label>
            <input class="csl-crm-input" type="text" id="csl-crm-city" autocomplete="address-level2" />
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-country">Pays</label>
            <input class="csl-crm-input" type="text" id="csl-crm-country" autocomplete="country-name" />
          </div>
        </div>
      </fieldset>

      <fieldset class="csl-crm-section">
        <legend>Qualification</legend>
        <label class="csl-crm-label" for="csl-crm-product">Produit ou service recherché</label>
        <div class="csl-crm-combobox" data-searchable data-free-text="true">
          <input class="csl-crm-input" type="text" id="csl-crm-product" role="combobox" aria-expanded="false" aria-controls="csl-crm-product-options" autocomplete="off" placeholder="Rechercher ou saisir un produit…" />
          <div class="csl-crm-options" id="csl-crm-product-options" role="listbox" hidden>${productOptions}</div>
        </div>

        <div class="csl-crm-grid">
          <div>
            <label class="csl-crm-label" for="csl-crm-stage">Étape</label>
            <div class="csl-crm-combobox" data-searchable>
              <input type="hidden" id="csl-crm-stage" value="contacted" />
              <input class="csl-crm-input" type="text" id="csl-crm-stage-search" role="combobox" aria-expanded="false" aria-controls="csl-crm-stage-options" autocomplete="off" value="Contacté" placeholder="Rechercher une étape…" />
              <div class="csl-crm-options" id="csl-crm-stage-options" role="listbox" hidden>${stageOptions}</div>
            </div>
          </div>
          <div>
            <label class="csl-crm-label" for="csl-crm-value">Valeur estimée (FCFA)</label>
            <input class="csl-crm-input" type="number" min="0" step="1000" id="csl-crm-value" inputmode="numeric" />
          </div>
        </div>

        <label class="csl-crm-label" for="csl-crm-followup">Prochaine relance</label>
        <input class="csl-crm-input" type="date" id="csl-crm-followup" />

        <label class="csl-crm-label" for="csl-crm-notes">Contexte et prochaine action</label>
        <textarea class="csl-crm-input" id="csl-crm-notes" rows="3" placeholder="Besoin, objection, décision attendue…"></textarea>

        <label class="csl-crm-consent" for="csl-crm-contactable">
          <input type="checkbox" id="csl-crm-contactable" checked />
          <span>Ce contact accepte d'être recontacté</span>
        </label>
      </fieldset>

      <div class="csl-crm-actions">
        <button type="submit" id="csl-crm-save" class="csl-crm-btn-primary">Enregistrer</button>
      </div>

      <div id="csl-crm-status" class="csl-crm-status" hidden></div>
    </form>
  `;
}

function buildSearchableOptions(options) {
  return options.map((option) =>
    `<button type="button" class="csl-crm-option" role="option" data-value="${escapeHtml(option.value)}">${escapeHtml(option.label)}</button>`
  ).join("");
}

function initializeSearchableDropdowns(panel) {
  panel.querySelectorAll("[data-searchable]").forEach((combobox) => {
    const inputs = combobox.querySelectorAll("input");
    const searchInput = inputs[inputs.length - 1];
    const valueInput = inputs.length > 1 ? inputs[0] : searchInput;
    const optionsBox = combobox.querySelector("[role='listbox']");
    const options = Array.from(optionsBox.querySelectorAll("[role='option']"));
    let activeIndex = -1;

    const render = () => {
      const query = searchInput.value.trim().toLocaleLowerCase("fr");
      const visible = options.filter((option) => {
        const matches = option.textContent.toLocaleLowerCase("fr").includes(query);
        option.hidden = !matches;
        option.classList.remove("csl-crm-option-active");
        return matches;
      });
      activeIndex = -1;
      optionsBox.hidden = false;
      searchInput.setAttribute("aria-expanded", "true");
      return visible;
    };

    const close = () => {
      optionsBox.hidden = true;
      searchInput.setAttribute("aria-expanded", "false");
      activeIndex = -1;
    };

    const choose = (option) => {
      searchInput.value = option.textContent.trim();
      valueInput.value = option.dataset.value;
      valueInput.dispatchEvent(new Event("input", { bubbles: true }));
      close();
    };

    options.forEach((option) => option.addEventListener("click", () => choose(option)));
    searchInput.addEventListener("focus", render);
    searchInput.addEventListener("input", () => {
      if (combobox.dataset.freeText === "true") valueInput.value = searchInput.value;
      render();
    });
    searchInput.addEventListener("keydown", (event) => {
      const visible = options.filter((option) => !option.hidden);
      if (event.key === "Escape") return close();
      if (event.key === "ArrowDown" || event.key === "ArrowUp") {
        event.preventDefault();
        if (optionsBox.hidden) render();
        activeIndex = event.key === "ArrowDown"
          ? Math.min(activeIndex + 1, visible.length - 1)
          : Math.max(activeIndex - 1, 0);
        visible.forEach((option) => option.classList.remove("csl-crm-option-active"));
        if (visible[activeIndex]) visible[activeIndex].classList.add("csl-crm-option-active");
      }
      if (event.key === "Enter" && visible[activeIndex]) {
        event.preventDefault();
        choose(visible[activeIndex]);
      }
    });
    searchInput.addEventListener("blur", () => setTimeout(close, 120));
  });
}

function previewGroupImport() {
  const panel = document.getElementById(PANEL_ID);
  const section = panel.querySelector("#csl-crm-group-import");
  const button = panel.querySelector("#csl-crm-group-preview");
  const resultEl = panel.querySelector("#csl-crm-group-result");
  const payload = {
    groupJid: section.dataset.groupJid,
    groupName: section.dataset.groupName,
    dryRun: true,
  };
  button.disabled = true;
  button.textContent = "Analyse du groupe...";
  chrome.runtime.sendMessage({ type: "importGroup", payload }, (response) => {
    button.disabled = false;
    button.textContent = "Prévisualiser les membres";
    if (chrome.runtime.lastError || !response || response.error) {
      setStatus(resultEl, "error", describeError(response && response.error, response && response.status));
      return;
    }
    setStatus(resultEl, "success", `${response.members} membres : ${response.created} nouveaux, ${response.merged} déjà connus, ${response.skipped} ignorés.`);
    if (response.created + response.merged === 0) return;
    button.textContent = "Confirmer l'import sécurisé";
    button.onclick = () => confirmGroupImport(payload, button, resultEl);
  });
}

function confirmGroupImport(payload, button, resultEl) {
  button.disabled = true;
  button.textContent = "Import en cours...";
  chrome.runtime.sendMessage({ type: "importGroup", payload: { ...payload, dryRun: false } }, (response) => {
    button.disabled = false;
    button.textContent = "Importer à nouveau";
    button.onclick = previewGroupImport;
    if (chrome.runtime.lastError || !response || response.error) {
      setStatus(resultEl, "error", describeError(response && response.error, response && response.status));
      return;
    }
    setStatus(resultEl, "success", `✓ ${response.created} contacts créés, ${response.merged} fusionnés. ${response.consentPending} attendent un consentement.`);
  });
}

function showHint(panel, text) {
  const hint = panel.querySelector("#csl-crm-hint");
  hint.textContent = text;
  hint.hidden = false;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function onSubmit(e) {
  e.preventDefault();

  const panel = document.getElementById(PANEL_ID);
  const saveBtn = panel.querySelector("#csl-crm-save");
  const statusEl = panel.querySelector("#csl-crm-status");

  const payload = {
    phone: panel.querySelector("#csl-crm-phone").value.trim(),
    name: panel.querySelector("#csl-crm-name").value.trim() || undefined,
    email: panel.querySelector("#csl-crm-email").value.trim() || undefined,
    company: panel.querySelector("#csl-crm-company").value.trim() || undefined,
    city: panel.querySelector("#csl-crm-city").value.trim() || undefined,
    country: panel.querySelector("#csl-crm-country").value.trim() || undefined,
    product_interest: panel.querySelector("#csl-crm-product").value.trim() || undefined,
    value_fcfa: Number(panel.querySelector("#csl-crm-value").value) || undefined,
    next_followup_at: panel.querySelector("#csl-crm-followup").value || undefined,
    opt_out: !panel.querySelector("#csl-crm-contactable").checked,
    stage: panel.querySelector("#csl-crm-stage").value,
    notes: panel.querySelector("#csl-crm-notes").value.trim() || undefined,
    source: "whatsapp-crm",
  };

  if (!payload.phone) {
    setStatus(statusEl, "error", "Le téléphone est requis.");
    return;
  }

  saveBtn.disabled = true;
  saveBtn.textContent = "Enregistrement...";

  chrome.runtime.sendMessage({ type: "saveLead", payload }, (response) => {
    saveBtn.disabled = false;
    saveBtn.textContent = "Enregistrer";

    if (chrome.runtime.lastError) {
      setStatus(statusEl, "error", "Erreur d'extension : " + chrome.runtime.lastError.message);
      return;
    }

    if (!response || response.error) {
      setStatus(statusEl, "error", describeError(response && response.error, response && response.status));
      return;
    }

    const stageLabel =
      (STAGE_OPTIONS.find((s) => s.value === (response.lead && response.lead.stage)) || {}).label ||
      payload.stage;

    const message = response.created ? "✓ Lead créé" : "✓ Lead mis à jour (déjà connu)";
    setStatus(statusEl, "success", `${message} — étape : ${stageLabel}`);

    panel.querySelector("#csl-crm-form").dataset.dirty = "false";
  });
}

function describeError(error, status) {
  if (error === "not_configured") {
    return "Extension non configurée — clic droit sur l'icône → Options.";
  }
  if (status === 401 || error === "http_401") {
    return "Token invalide — configurez l'extension (clic droit sur l'icône → Options).";
  }
  if (error === "timeout") {
    return "Le serveur ne répond pas (délai dépassé).";
  }
  if (error === "network_error") {
    return "Erreur réseau — vérifiez votre connexion.";
  }
  return `Erreur : ${error || "inconnue"}`;
}

function setStatus(statusEl, kind, text) {
  statusEl.hidden = false;
  statusEl.className = `csl-crm-status csl-crm-status-${kind}`;
  statusEl.textContent = text;
}

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------

waitForWhatsAppReady();
